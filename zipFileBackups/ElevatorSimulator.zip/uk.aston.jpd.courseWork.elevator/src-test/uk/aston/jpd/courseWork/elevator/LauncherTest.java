package uk.aston.jpd.courseWork.elevator;

public class LauncherTest {

}
