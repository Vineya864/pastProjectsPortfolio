package courseWorkAnimation;

import java.util.Random;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.util.glu.Sphere;
import org.newdawn.slick.opengl.Texture;

import GraphicsLab.Colour;
import GraphicsLab.FloatBuffer;
import GraphicsLab.GraphicsLab;
import GraphicsLab.Normal;
import GraphicsLab.Vertex;
import Lab6.Lab6;

public class CourseWorkAnimation extends GraphicsLab
{
	 private final int planeList = 3;
	   private Texture groundTextures;
	private final int shipList  = 1;
	private final int cannonList  = 2;

	////////////////////////////////////
	public Vertex F1 = new Vertex(0.0f, 0.0f,  0.0f);
	public Vertex F2 = new Vertex(5.0f, 0.0f, 2.0f);
	public Vertex F3 = new Vertex(5.0f,0.0f,-2.0f);
	public Vertex F4 = new Vertex(5.0f,-3.0f,-1.0f);
	public Vertex F5 = new Vertex(5.0f,-3.0f,1.0f);
	
	//(0.0f, 0.0f,  0.0f);
	public Vertex B1 = new Vertex(18.0f, 0.0f,  0.0f);
	public Vertex B2 = new Vertex(15.0f, 0.0f, 2.0f);
	public Vertex B3 = new Vertex(15.0f,0.0f,-2.0f);
	public Vertex B4 = new Vertex(15.0f,-3.0f,-1.0f);
	public Vertex B5 = new Vertex(15.0f,-3.0f,1.0f);
	
	
	
	/////////////////////////////
	
//////////////////////////////////////////////////////
	private float rockZ;
	private float rockY;
	private int lastRock;
	private float timer;
	private boolean movingLeft;
	private boolean movingRight;
	private float baseX;
	private boolean sailDirection;
	private boolean fire;
	private float ballZ;
	private float ballX;
	private float ballY;
/** Draw the shape **/

	private void drawShip() 
	{  
	//	GL11.glPushMatrix();
		//{
		//GL11.glRotatef(-20.0f, 0.0f, 1.0f, 0.0f);	
	drawFront(); 
	drawBack();
	drawMid();
	drawMast();
		//}
	//	GL11.glPopMatrix();
	}

	


	  public static void main(String args[])
	    {  
		 
	    	new CourseWorkAnimation().run(WINDOWED,"Animation",0.00005f);
	    }

	@Override
	protected void initScene() throws Exception {
		//ballX=null;
		groundTextures = loadTexture("CourseWorkAnimation/textures/water-texture.bmp");
		
		
		 float globalAmbient[]   = {0.2f,  0.2f,  0.2f, 1f};
	        // set the global ambient lighting
	        GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT, FloatBuffer.wrap(globalAmbient));

	        
	        // the first light for the scene is white...
	        float diffuse0[]  = { 0.6f,  0.6f, 0.6f, 1.0f};
	        // ...with a dim ambient contribution...
	        float ambient0[]  = { 0.1f,  0.1f, 0.1f, 1.0f};
	        // ...and is positioned above and behind the viewpoint
	        float position0[] = { 0.0f, 10.0f, 5.0f, 1.0f}; 

	        // supply OpenGL with the properties for the first light
	        GL11.glLight(GL11.GL_LIGHT0, GL11.GL_AMBIENT, FloatBuffer.wrap(ambient0));
	        GL11.glLight(GL11.GL_LIGHT0, GL11.GL_DIFFUSE, FloatBuffer.wrap(diffuse0));
	  		GL11.glLight(GL11.GL_LIGHT0, GL11.GL_SPECULAR, FloatBuffer.wrap(diffuse0));
	        GL11.glLight(GL11.GL_LIGHT0, GL11.GL_POSITION, FloatBuffer.wrap(position0));
	        // enable the first light
	        GL11.glEnable(GL11.GL_LIGHT0);
	        


	        // enable lighting calculations
	        GL11.glEnable(GL11.GL_LIGHTING);
	        // ensure that all normals are re-normalised after transformations automatically
	        GL11.glEnable(GL11.GL_NORMALIZE);
	        
		
		
		
		
	        movingRight=false;
	        movingLeft=false;
		 rockZ=0;
		 rockY=0;
		 timer=0;
		 baseX=0;
		 
		 
		
		 
		 
		 
		 
		// TODO Auto-generated method stub
		  GL11.glNewList(shipList,GL11.GL_COMPILE);
	        {   drawShip();
	        }
	        GL11.glEndList();
	        
	      
	        GL11.glNewList(planeList,GL11.GL_COMPILE);
	        {   drawUnitPlane();
	        }
	        GL11.glEndList();
	}
	     

	@Override
	protected void checkSceneInput() {
		movingLeft=false;
		movingRight=false;
		 if(Keyboard.isKeyDown(Keyboard.KEY_A))
        {   movingLeft = true;
        sailDirection=false;

        }
		 if(Keyboard.isKeyDown(Keyboard.KEY_D))
	        {   movingRight = true;
	        sailDirection=true;

	        }
		 
		 if(Keyboard.isKeyDown(Keyboard.KEY_F))
	        {   fire=true;

	        }
		
	}
	
	@Override
	 protected void updateScene()
	    {
		if (timer>0.1) {
	        Random rand= new Random();
	        int temp=rand.nextInt(2);
	        
	        if (temp==1 && !(temp==lastRock)) {
	        	rockZ=1;
	        	System.out.println(rockZ);
	        	rockY=1;
	        }else if (temp==0&& !(temp==lastRock)) {
	        	rockZ=-1;
	        	System.out.println(rockZ);
	        	rockY=-1;
	        }else {
	        	rockZ=0;
	        	System.out.println(rockZ);
	        	rockY=0;
	        }
	        lastRock=temp;
	        
	        timer=0;
	   
	    }
		timer=timer +(1.0f * getAnimationScale());
		   if(movingLeft) {
			      
			      if(baseX<-30.f) {
			    	  baseX= baseX;
			      }else {
			    	  baseX=baseX - 0.01f;
			      }
		      }
		   else if(movingRight) {
			      
			      if(baseX>10.f) {
			    	  baseX= baseX;
			      }else {
			    	  baseX=baseX + 0.01f;
			      }
		      }
		   
		   if (fire) {
			   if(ballZ==0 ) {
				   ballX=baseX;
				   ballY=0; 
			   }
			   ballZ=ballZ-0.002f;
			   
			
		   }
	    }

	@Override
	protected void renderScene() {
		
		 GL11.glPushMatrix();
	        {
	            // disable lighting calculations so that they don't affect
	            // the appearance of the texture 
	            GL11.glPushAttrib(GL11.GL_LIGHTING_BIT);
	            GL11.glDisable(GL11.GL_LIGHTING);
	            // change the geometry colour to white so that the texture
	            // is bright and details can be seen clearly
	            Colour.WHITE.submit();
	            // enable texturing and bind an appropriate texture
	            GL11.glEnable(GL11.GL_TEXTURE_2D);
	            GL11.glBindTexture(GL11.GL_TEXTURE_2D,groundTextures.getTextureID());
	            
	            // position, scale and draw the ground plane using its display list
	            GL11.glTranslatef(0.0f,-1.0f,-10.0f);
	            GL11.glScaled(25.0f, 1.0f, 20.0f);
	            GL11.glCallList(planeList);

	            // disable textures and reset any local lighting changes
	            GL11.glDisable(GL11.GL_TEXTURE_2D);
	            GL11.glPopAttrib();
	        }
	        GL11.glPopMatrix();
		
		////////////////////////////////////////////////////////////////
		
		// TODO Auto-generated method stub
		
		  // how shiny are the front faces of the house (specular exponent)
        float ShipFrontShininess  = .0f;
       
        float ShipFrontSpecular[] = {0.38f, .30f, 0.22f, 1.0f};
      
        float ShipFrontDiffuse[]  = {0.38f, 0.3f, 0.22f, 1.0f};
        
       
        GL11.glMaterialf(GL11.GL_FRONT, GL11.GL_SHININESS, ShipFrontShininess);
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_SPECULAR, FloatBuffer.wrap(ShipFrontSpecular));
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_DIFFUSE, FloatBuffer.wrap(ShipFrontDiffuse));
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT, FloatBuffer.wrap(ShipFrontDiffuse));

	        
	        	GL11.glPushMatrix();{
	        		GL11.glTranslatef(baseX,0f,20f);
	        	GL11.glRotatef(rockZ*5,0.2f,0.0f, 0.0f);
	        //	GL11.glRotatef(rockY,0.0f,0.0f, 0.1f);
	        	
	        		
	        	}
	        	 GL11.glCallList(shipList);
	        	 
	        	 //GL11.glPopMatrix();
	        
	        	 GL11.glPopMatrix();
	        	 GL11.glPopMatrix();
	        	 GL11.glTranslatef(0f, 3f, -20f);
	        	 
	        	 GL11.glRotatef(rockZ*10,0.2f,0.0f, 0.0f);
	        	 GL11.glCallList(shipList);
	        	 GL11.glPopMatrix();
	        	 
	       // 	 GL11.glCallList(cannonList);
	        	
	        	 
	        	
	        	
	       
	}
			
	  protected void setSceneCamera()
	    {
	    	// call the default behaviour defined in GraphicsLab. This will set a default 
	    	// perspective projection and default camera settings ready 
	    	// for some custom camera positioning below...  
	    	super.setSceneCamera();
	        
	        // set the actual viewpoint using the gluLookAt command. This specifies the 
	    	// viewer's (x,y,z) position, the point the viewer is looking 
	    	// at (x,y,z) and the view-up direction (x,y,z), typically (0,1,0) - 
	    	// i.e. the y-axis defines the up direction
	        GLU.gluLookAt(0.0f, 0.0f, 50.0f,   // viewer location        
	        		      0.0f, 0.0f, 0.0f,    // view point loc.
	        		      0.0f, 1.0f, 0.0f);   // view-up vector
	   }
	  
	  
	  
	  
	
	  
	  
	  
	  
	  
	  
	  
	  
	  ///////////////////////////////////////////////////////////////////////////////////////////////
		
	    private void drawFront()  {
	    	

		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			F2.submit();
			F3.submit();
				F4.submit();
				F5.submit();



		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			F1.submit();
			F2.submit();
			F3.submit();
			F1.submit();



		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			F4.submit();
			F5.submit();
			F1.submit();



		}
		GL11.glEnd();

		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			F3.submit();
			F4.submit();
			F1.submit();



		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			F5.submit();
			F2.submit();
			F1.submit();



		}
		GL11.glEnd();
		 Vertex FH1 = new Vertex(-1.5f, -0.0f,  0.0f);
         Vertex FH2 = new Vertex(-1.5f,  .00f,  0.0f);
         Vertex FH3 = new Vertex( 1.0f,  .20f,  0.f);
         Vertex FH4 = new Vertex( 1.0f, -0.2f,  0.0f);
         Vertex FH5 = new Vertex(-1.5f, -0.f, .0f);
         Vertex FH6 = new Vertex(-1.5f,  .00f, .0f);
         Vertex FH7 = new Vertex( 1.f,  .2f, .0f);
         Vertex FH8 = new Vertex( 1.0f, -.2f, .0f);

         GL11.glPushMatrix();{
      	  // GL11.glTranslatef(1.0f,0.0f,-0.1f);
         GL11.glRotatef(40.0f, 1.0f, -0.0f, -0.2f);
         //GL11.glRotatef(90.0f, .0f, .0f, 0.0f);
         }
         GL11.glBegin(GL11.GL_POLYGON);
         {
             FH3.submit();
             FH2.submit();
             FH1.submit();
             FH4.submit();
         }
         GL11.glEnd();

        
        
         GL11.glBegin(GL11.GL_POLYGON);
         {
         	FH2.submit();
             FH6.submit();
             FH5.submit();
             FH1.submit();
         }
         GL11.glEnd();

     
        
         GL11.glBegin(GL11.GL_POLYGON);
         {
             FH7.submit();
             FH3.submit();
             FH4.submit();
            FH8.submit();
         }
         GL11.glEnd();

        
      
         GL11.glBegin(GL11.GL_POLYGON);
         {
             FH7.submit();
             FH6.submit();
             FH2.submit();
             FH3.submit();
         }
         GL11.glEnd();

      
        
         GL11.glBegin(GL11.GL_POLYGON);
         {
             FH4.submit();
             FH1.submit();
             FH5.submit();
             FH8.submit();
         }
         GL11.glEnd();

     
       
         GL11.glBegin(GL11.GL_POLYGON);
         {
             FH6.submit();
             FH7.submit();
             FH8.submit();
             FH5.submit();
         }
         GL11.glEnd();
         GL11.glPopMatrix();
		

	}



	private void drawBack()  {

		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			B2.submit();
			B3.submit();
			B4.submit();
			B5.submit();



		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			B1.submit();
			B2.submit();
			B3.submit();
			B1.submit();



		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			//   B1.submit(); 
			B4.submit();
			B5.submit();
			B1.submit();



		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			B3.submit();
			B4.submit();
			B1.submit();



		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			//  B1.submit(); 
			B5.submit();
			B2.submit();
			B1.submit();



		}
		GL11.glEnd();

	}


	private void drawMid() {
			GL11.glBegin(GL11.GL_POLYGON);
			{
				F2.submit();
				B2.submit();
				B3.submit();
				F3.submit();
				F2.submit();
	
		}
		GL11.glEnd();
		
		
		GL11.glBegin(GL11.GL_POLYGON);
			{
			F3.submit();
			B3.submit();
			B4.submit();
			F4.submit();
			F3.submit();
			/*F3.submit();
			F4.submit();
			B4.submit();
			B5.submit();
			F5.submit();
			F2.submit();*/
			}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
			{
			F4.submit();
			B4.submit();
			B5.submit();
			F5.submit();
			F4.submit();
			/*F3.submit();
			F4.submit();
			B4.submit();
			B5.submit();
			F5.submit();
			F2.submit();*/
			}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
			{
			F5.submit();
			B5.submit();
			B1.submit();
			F1.submit();
			F5.submit();
			/*F3.submit();
			F4.submit();
			B4.submit();
			B5.submit();
			F5.submit();
			F2.submit();*/
			}
			GL11.glEnd();
	}
	
	private void drawMast() {
		  float ShipFrontShininess  = .1f;
	        // specular reflection of the front faces of the house
	        float ShipFrontSpecular[] = {0.38f, .30f, 0.22f, 1.0f};
	        // diffuse reflection of the front faces of the house
	        float ShipFrontDiffuse[]  = {0.38f, 0.3f, 0.22f, 1.0f};
	        
	     
		        
		GL11.glPushMatrix();
		{       
		
		GL11.glTranslatef(12.0f, 0.f, 0.0f);
		drawSail(movingRight);
		   // set the material properties for the house using OpenGL
        GL11.glMaterialf(GL11.GL_FRONT, GL11.GL_SHININESS, ShipFrontShininess);
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_SPECULAR, FloatBuffer.wrap(ShipFrontSpecular));
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_DIFFUSE, FloatBuffer.wrap(ShipFrontDiffuse));
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT, FloatBuffer.wrap(ShipFrontDiffuse));

		
		GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		new Cylinder().draw(0.25f, 0.25f, 4.5f, 10, 10);
		
		
		GL11.glTranslatef(-6.0f, 0.0f, 0.0f);
		GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
		drawSail(movingRight);
		   // set the material properties for the house using OpenGL
        GL11.glMaterialf(GL11.GL_FRONT, GL11.GL_SHININESS, ShipFrontShininess);
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_SPECULAR, FloatBuffer.wrap(ShipFrontSpecular));
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_DIFFUSE, FloatBuffer.wrap(ShipFrontDiffuse));
        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT, FloatBuffer.wrap(ShipFrontDiffuse));

		GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		new Cylinder().draw(0.25f, 0.25f, 4.5f, 10, 10);
		
		}
		GL11.glPopMatrix();
		
	}
	private void drawSail(boolean direction) {
		
		
		 Vertex S1 =new Vertex(0f,1.5f,0f);//0-5
		Vertex S2 =new Vertex(1f,1.5f,0f);
		 Vertex S3 =new Vertex(2f,1.5f,0f);
		Vertex S4 =new Vertex(3f,1.5f,0f);
		 Vertex S5 =new Vertex(4f,1.5f,0f);
		 Vertex S6 =new Vertex(5f,1.5f,0f);
		
		 Vertex S7 =new Vertex(4f,2.1f,0f);
		 Vertex S8 =new Vertex(3f,2.7f,0f);
		 Vertex S9 =new Vertex(2f,3.3f,0f);
		 Vertex S10 =new Vertex(1f,3.9f,0f);
		 Vertex S11 =new Vertex(0f,4.5f,0f);
		
		 Vertex S12 =new Vertex(0f,1.5f,0.3f);//0-5
		 Vertex S13 =new Vertex(1f,1.5f,0.3f);
		 Vertex S14 =new Vertex(2f,1.5f,0.3f);
		 Vertex S15=new Vertex(3f,1.5f,0.3f);
		 Vertex S16=new Vertex(4f,1.5f,0.3f);
		 Vertex S17 =new Vertex(5f,1.5f,0.3f);
		
		 Vertex S18 =new Vertex(4f,2.1f,0.3f);
		 Vertex S19 =new Vertex(3f,2.7f,0.3f);
		 Vertex S20 =new Vertex(2f,3.3f,0.3f);
		 Vertex S21 =new Vertex(1f,3.9f,0.3f);
		 Vertex S22 =new Vertex(0f,4.5f,0.3f);
		GL11.glPushMatrix();{
		
			float SailFrontShininess  = 0.1f;
	        // specular reflection of the front faces of the house
	        float SailFrontSpecular[] = {1.f, 1.0f, 1.0f, 1.0f};
	        // diffuse reflection of the front faces of the house
	        float SailFrontDiffuse[]  = {1.0f, 1.0f, 1.0f, 1.0f};
	        
	        // set the material properties for the house using OpenGL
	        GL11.glMaterialf(GL11.GL_FRONT, GL11.GL_SHININESS, SailFrontShininess);
	        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_SPECULAR, FloatBuffer.wrap(SailFrontSpecular));
	        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_DIFFUSE, FloatBuffer.wrap(SailFrontDiffuse));
	        GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT, FloatBuffer.wrap(SailFrontDiffuse));
		
		 // GL11.glTranslatef(0.0f, 0.0f, -0.3f);
		GL11.glBegin(GL11.GL_POLYGON);
		{
		S1.submit();
		S2.submit();
		S3.submit();
		S4.submit();
		S5.submit();
		S6.submit();
		S7.submit();
		S8.submit();
		S9.submit();
		S10.submit();
		S11.submit();
		S1.submit();
	
		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_POLYGON);
		{
			S1.submit();
			S11.submit();
			S10.submit();
			S9.submit();
			S8.submit();
			S7.submit();
			S6.submit();
			S5.submit();
			S4.submit();
			S3.submit();
			S2.submit();
			S1.submit();
		}
		GL11.glEnd();
		
       
		
		GL11.glBegin(GL11.GL_POLYGON);
		{
		S12.submit();
		S13.submit();
		S14.submit();
		S15.submit();
		S16.submit();
		S17.submit();
		S18.submit();
		S19.submit();
		S20.submit();
		S21.submit();
		S22.submit();
		S12.submit();
	
		}
		GL11.glEnd();
        }
        

        
        GL11.glBegin(GL11.GL_POLYGON);
		{
			S6.submit();
			S17.submit();
			S12.submit();
			S1.submit();
			S6.submit();
	
		}
		GL11.glEnd();
		 GL11.glBegin(GL11.GL_POLYGON);
			{
				S6.submit();
				S11.submit();
				S22.submit();
				S17.submit();
				S6.submit();
		
			}
			GL11.glEnd();
        GL11.glPopMatrix();
	}

	
	public void shipFire() {
		
	}
	public void drawCannon() {
		
		GL11.glTranslatef(ballX, ballY, ballZ);
		new Sphere().draw(0.5f,10,10);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	  private void drawUnitPlane()
	    {
	        Vertex v1 = new Vertex(-2.0f, -3.5f,-2.5f); // left,  back
	        Vertex v2 = new Vertex( 3.0f, -3.5f,-2.5f); // right, back
	        Vertex v3 = new Vertex( 3.0f, -3.5f, 3.5f); // right, front
	        Vertex v4 = new Vertex(-2.0f, -3.5f, 3.5f); // left,  front
	        
	        // draw the plane geometry. order the vertices so that the plane faces up
	        GL11.glBegin(GL11.GL_POLYGON);
	        {
	            new Normal(v4.toVector(),v3.toVector(),v2.toVector(),v1.toVector()).submit();
	            
	            GL11.glTexCoord2f(0.0f,0.0f);
	            v4.submit();
	            
	            GL11.glTexCoord2f(1.0f,0.0f);
	            v3.submit();
	            
	            GL11.glTexCoord2f(1.0f,1.0f);
	            v2.submit();
	            
	            GL11.glTexCoord2f(0.0f,1.0f);
	            v1.submit();
	        }
	        GL11.glEnd();
	        
	        // if the user is viewing an axis, then also draw this plane
	        // using lines so that axis aligned planes can still be seen
	        if(isViewingAxis())
	        {
	            // also disable textures when drawing as lines
	            // so that the lines can be seen more clearly
	            GL11.glPushAttrib(GL11.GL_TEXTURE_2D);
	            GL11.glDisable(GL11.GL_TEXTURE_2D);
	            GL11.glBegin(GL11.GL_LINE_LOOP);
	            {
	                v4.submit();
	                v3.submit();
	                v2.submit();
	                v1.submit();
	            }
	            GL11.glEnd();
	            GL11.glPopAttrib();
	        }
	    }

}
