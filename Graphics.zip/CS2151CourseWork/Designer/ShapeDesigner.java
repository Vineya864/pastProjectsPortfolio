package Designer;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;
import org.newdawn.slick.opengl.Texture;
import org.lwjgl.util.glu.Cylinder;
import GraphicsLab.Colour;
import GraphicsLab.Normal;
import GraphicsLab.Vertex;

/**
 * The shape designer is a utility class which assits you with the design of 
 * a new 3D object. Replace the content of the drawUnitShape() method with
 * your own code to creates vertices and draw the faces of your object.
 * 
 * You can use the following keys to change the view:
 *   - TAB		switch between vertex, wireframe and full polygon modes
 *   - UP		move the shape away from the viewer
 *   - DOWN     move the shape closer to the viewer
 *   - X        rotate the camera around the x-axis (clockwise)
 *   - Y or C   rotate the camera around the y-axis (clockwise)
 *   - Z        rotate the camera around the z-axis (clockwise)
 *   - SHIFT    keep pressed when rotating to spin anti-clockwise
 *   - A 		Toggle colour (only if using submitNextColour() to specify colour)
 *   - SPACE	reset the view to its initial settings
 *  
 * @author Remi Barillec
 *
 */
public class ShapeDesigner extends AbstractDesigner {
	
	/** Main method **/
	public static void main(String args[])
    {   
		new ShapeDesigner().run( WINDOWED, "Designer", 0.01f);
    }
		
	////////////////////////////////////
	public Vertex F1 = new Vertex(0.0f, 0.0f,  0.0f);
	public Vertex F2 = new Vertex(5.0f, 0.0f, 2.0f);
	public Vertex F3 = new Vertex(5.0f,0.0f,-2.0f);
	public Vertex F4 = new Vertex(5.0f,-3.0f,-1.0f);
	public Vertex F5 = new Vertex(5.0f,-3.0f,1.0f);
	
	//(0.0f, 0.0f,  0.0f);
	public Vertex B1 = new Vertex(20.0f, 0.0f,  0.0f);
	public Vertex B2 = new Vertex(15.0f, 0.0f, 2.0f);
	public Vertex B3 = new Vertex(15.0f,0.0f,-2.0f);
	public Vertex B4 = new Vertex(15.0f,-3.0f,-1.0f);
	public Vertex B5 = new Vertex(15.0f,-3.0f,1.0f);
	
	
	
	/////////////////////////////
	public Vertex S1 =new Vertex(0f,2f,0f);//0-5
	public Vertex S2 =new Vertex(1f,2f,0f);
	public Vertex S3 =new Vertex(2f,2f,0f);
	public Vertex S4 =new Vertex(3f,2f,0f);
	public Vertex S5 =new Vertex(4f,2f,0f);
	public Vertex S6 =new Vertex(5f,2f,0f);
	
	public Vertex S7 =new Vertex(4f,2.6f,0f);
	public Vertex S8 =new Vertex(3f,3.2f,0f);
	public Vertex S9 =new Vertex(2f,3.8f,0f);
	public Vertex S10 =new Vertex(1f,4.4f,0f);
	public Vertex S11 =new Vertex(0f,5f,0f);
	
	/** Draw the shape **/
	@Override
	protected void drawUnitShape() 
    {  
		
		drawFront(); 
		drawBack();
		drawMid();
		drawMast();
    }
	
	private void drawFront()  {
	
		GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       F2.submit();
       F3.submit();
       F4.submit();
       F5.submit();
      
       
    
    	}
    	GL11.glEnd();
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       F1.submit();
       F2.submit();
       F3.submit();
       F1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       F4.submit();
       F5.submit();
       F1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       F3.submit();
       F4.submit();
       F1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       F5.submit();
       F2.submit();
       F1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	
	}
	
	
	
	private void drawBack()  {
		
		GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       B2.submit();
       B3.submit();
       B4.submit();
       B5.submit();
      
       
    
    	}
    	GL11.glEnd();
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       B1.submit();
       B2.submit();
       B3.submit();
       B1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
    //   B1.submit(); 
       B4.submit();
       B5.submit();
       B1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       B3.submit();
       B4.submit();
       B1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	GL11.glBegin(GL11.GL_POLYGON);
    	{
     //  B1.submit(); 
       B5.submit();
       B2.submit();
       B1.submit();
      
       
    
    	}
    	GL11.glEnd();
    	
	}
	
	
	private void drawMid() {
		GL11.glBegin(GL11.GL_POLYGON);
    	{
		F2.submit();
		B2.submit();
		B3.submit();
		F3.submit();
		F2.submit();
		/*F3.submit();
		F4.submit();
		B4.submit();
		B5.submit();
		F5.submit();
		F2.submit();*/
    	}
    	GL11.glEnd();
	
	
	GL11.glBegin(GL11.GL_POLYGON);
	{
	F3.submit();
	B3.submit();
	B4.submit();
	F4.submit();
	F3.submit();
	/*F3.submit();
	F4.submit();
	B4.submit();
	B5.submit();
	F5.submit();
	F2.submit();*/
	}
	GL11.glEnd();
	GL11.glBegin(GL11.GL_POLYGON);
	{
	F4.submit();
	B4.submit();
	B5.submit();
	F5.submit();
	F4.submit();
	/*F3.submit();
	F4.submit();
	B4.submit();
	B5.submit();
	F5.submit();
	F2.submit();*/
	}
	GL11.glEnd();
	GL11.glBegin(GL11.GL_POLYGON);
	{
	F5.submit();
	B5.submit();
	B1.submit();
	F1.submit();
	F5.submit();
	/*F3.submit();
	F4.submit();
	B4.submit();
	B5.submit();
	F5.submit();
	F2.submit();*/
	}
	GL11.glEnd();
}
	
	private void drawMast() {
		GL11.glPushMatrix();
        {
	
		GL11.glTranslatef(12.0f, 0.0f, 0.0f);
		drawSail();
		
		
		GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		new Cylinder().draw(0.25f, 0.25f, 4.5f, 10, 10);
		
		
		GL11.glTranslatef(-6.0f, 0.0f, 0.0f);
		GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
	drawSail();
		
	GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		new Cylinder().draw(0.25f, 0.25f, 4.5f, 10, 10);
		
	 }
    GL11.glPopMatrix();
        
	}
	private void drawSail() {
		GL11.glBegin(GL11.GL_POLYGON);
		{
		S1.submit();
		S2.submit();
		S3.submit();
		S4.submit();
		S5.submit();
		S6.submit();
		S7.submit();
		S8.submit();
		S9.submit();
		S10.submit();
		S11.submit();
		S1.submit();
	
		}
		GL11.glEnd();
	}
	
}
		
		
	
    
